#define TO_RDONLY  0x000
#define TO_WRONLY  0x001
#define TO_RDWR    0x002
#define TO_CREATE  0x200
